#ifndef _HEAPSORT_H
#define _HEAPSORT_H 1
void heapSort(Node** arr, int size);
#endif
